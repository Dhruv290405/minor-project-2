"""
Generate the Minor-Project report for the "Distributed Diabetes Risk Assessment System",
strictly following the AITR/RGPV report template
(report/Project Report Format_ver2.0_MinorProject.docx).

Single source of truth (the BODY blocks + front-matter text below), two renderers:
  - DocxRenderer -> a submittable Word .docx (cover with logo, headings, tables, figures)
  - MdRenderer   -> report/REPORT.md (editable Markdown master)

Personal fields (student names, roll/enrollment numbers, guide name, dates) are intentionally
left as <<placeholders>> for the team to fill in.

Run:  ./venv/bin/python report/build_report.py
"""

import os
import shutil

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION

HERE = os.path.dirname(os.path.abspath(__file__))
FIG = os.path.join(HERE, "figures")
ASSETS = os.path.join(HERE, "assets")
DOCX_OUT = os.path.join(HERE, "Distributed_Diabetes_Risk_Assessment_System_Report.docx")
MD_OUT = os.path.join(HERE, "REPORT.md")
LOGO = os.path.join(ASSETS, "acropolis_logo.png")

TITLE = "Distributed Diabetes Risk Assessment System"
SESSION = "2025-2026"

# ===========================================================================
# Figure / Table registries (auto-build the List of Figures / List of Tables)
# ===========================================================================
FIGURES = []  # (label, caption)
TABLES = []   # (label, caption)


def fig(filename, caption):
    label = f"Figure {len(FIGURES) + 1}"
    FIGURES.append((label, caption))
    return ("fig", filename, f"{label}: {caption}")


def tbl(caption, headers, rows):
    label = f"Table {len(TABLES) + 1}"
    TABLES.append((label, caption))
    return ("tbl", f"{label}: {caption}", headers, rows)


# ===========================================================================
# BODY — chapters, references, appendices
# ===========================================================================
def body_blocks():
    B = []
    h, p, b, n, code, pb = (
        lambda l, t: ("h", l, t), lambda t: ("p", t), lambda items: ("b", items),
        lambda items: ("n", items), lambda t: ("code", t), ("pb",),
    )

    # ---- Chapter 1 ----------------------------------------------------------
    B += [
        ("h", 1, "Chapter 1 — Introduction & Background"),
        ("h", 2, "1.1 Problem Context (Real-world Scenario)"),
        p("Diabetes mellitus is one of the fastest-growing chronic diseases worldwide, and a "
          "large fraction of cases — especially Type-2 — remain undiagnosed for years. In a "
          "screening setting (a community health camp, a primary-care clinic, or a tele-health "
          "portal), a low-cost predictive test is used to decide which patients should be sent "
          "for confirmatory laboratory diagnosis. The defining characteristic of this domain is "
          "that the two possible errors are NOT equally harmful. A false negative — telling a "
          "diabetic patient that they are healthy — sends a genuinely sick person home with no "
          "follow-up, allowing the disease to progress untreated. A false positive — flagging a "
          "healthy person for a blood test that turns out negative — costs only the price and "
          "inconvenience of that test. In clinical screening the false negative is the dangerous, "
          "expensive error."),
        ("h", 2, "1.2 Motivation & Need"),
        p("Standard machine-learning classifiers, including gradient-boosted trees, are trained "
          "to minimise a symmetric loss (log-loss) that treats both error types as equally bad. "
          "On a class-imbalanced screening dataset this quietly maximises overall accuracy while "
          "accepting a high rate of missed diabetics. A safe screening tool must instead be "
          "explicitly biased toward sensitivity (recall). This project is motivated by the need "
          "for a diagnostic aid whose mathematics encode the real clinical cost of a missed "
          "diagnosis, while remaining transparent (explainable) to the clinician using it."),
        ("h", 2, "1.3 Why Current Solutions Are Insufficient"),
        b([
            "Most published diabetes-prediction models optimise accuracy or AUC and report those "
            "as success metrics, hiding a poor false-negative rate.",
            "Class-imbalance is often handled only by resampling (SMOTE) or the single "
            "scale_pos_weight knob, rather than a purpose-built cost-sensitive loss.",
            "Many models are 'black boxes' offered without per-prediction explanations, which "
            "clinicians cannot trust or act on.",
            "Research prototypes are frequently single scripts, not deployable, distributed "
            "systems with a usable interface and persistent record-keeping.",
        ]),
        ("h", 2, "1.4 Literature Review / Existing Solutions"),
        b([
            "Chen & Guestrin (2016), XGBoost — the scalable gradient-boosting framework used here; "
            "natively supports user-defined objective functions.",
            "Lin et al. (2017), Focal Loss — introduces the (1-p)^gamma modulating factor that "
            "focuses training on hard examples; adapted in this work as a cost-sensitive objective.",
            "Elkan (2001), The Foundations of Cost-Sensitive Learning — formalises learning when "
            "error costs are asymmetric.",
            "Lundberg & Lee (2017), SHAP — game-theoretic per-feature attributions, used here to "
            "explain every individual risk score.",
            "Smith et al. (1988) and the UCI Pima Indians Diabetes dataset — the standard benchmark "
            "used for evaluation; existing studies on it rarely target the false-negative rate.",
        ]),
        ("h", 2, "1.5 Problem Statement"),
        p("Given the eight standard diagnostic measurements of a patient, predict the risk of "
          "diabetes such that the number of false negatives (missed diabetics) is minimised "
          "without materially degrading the model's ranking ability (ROC-AUC), and deliver this "
          "prediction — together with a human-readable explanation — through a reliable, "
          "distributed web application that persists every assessment."),
        ("h", 2, "1.6 Proposed Solution Overview"),
        p("We build a four-tier distributed system: a React single-page interface, a Node.js/"
          "Express API gateway, a Python/FastAPI machine-learning microservice, and a MongoDB "
          "store. The ML core replaces XGBoost's standard log-loss with a custom, cost-sensitive "
          "objective function whose gradient makes a missed diabetic far more expensive than a "
          "false alarm. SHAP produces a per-patient breakdown of risk and protective factors."),
        ("h", 2, "1.7 Objectives"),
        b([
            "Design and implement three custom XGBoost objective functions (weighted "
            "cross-entropy, focal loss, exponential false-negative penalty) with analytically "
            "derived gradient and hessian.",
            "Demonstrate, under a repeated cross-validation protocol, a statistically stable "
            "increase in recall and reduction in false negatives versus standard XGBoost.",
            "Preserve ranking quality (ROC-AUC) so the gain is a safer operating point, not a "
            "worse model.",
            "Serve the winning model in real time with per-prediction SHAP explanations.",
            "Persist every assessment and expose a paginated history.",
        ]),
        ("h", 2, "1.8 Contributions"),
        b([
            "A purpose-built exponential false-negative loss for XGBoost, with a bounded gradient "
            "and a stable Gauss-Newton hessian approximation.",
            "A controlled, reproducible comparison (5-fold x 5-seed) isolating the loss function "
            "as the only variable.",
            "A complete, deployable distributed system around the model, not just a notebook.",
            "Identification and correct handling of the custom-objective serving pitfall "
            "(manual sigmoid on raw margins).",
        ]),
        ("h", 2, "1.9 Scope & Limitations"),
        p("Scope: tabular risk screening on the eight Pima features, an explainable real-time "
          "API, and a web UI with history. Limitations: the model is trained on the public Pima "
          "cohort (adult female patients of Pima heritage) and is a research/educational artifact, "
          "not a certified medical device; cost-sensitive training deliberately produces an "
          "uncalibrated risk score rather than a literal probability."),
        ("h", 2, "1.10 Organization of Report"),
        p("Chapter 2 covers requirements and planning; Chapter 3 the system design and "
          "architecture; Chapter 4 the methodology and model development; Chapter 5 implementation "
          "and testing; Chapter 6 results, analysis and discussion; Chapter 7 deployment; and "
          "Chapter 8 the conclusion and future work, followed by references and appendices."),
        pb,
    ]

    # ---- Chapter 2 ----------------------------------------------------------
    B += [
        ("h", 1, "Chapter 2 — Requirements & Planning"),
        ("h", 2, "2.1 Stakeholders & Users"),
        b([
            "Screening clinicians / health-camp staff — primary users who enter patient vitals "
            "and read the risk score and explanation.",
            "Patients — the subjects of the assessment, indirectly served by safer triage.",
            "Administrators / researchers — review the stored history and model behaviour.",
        ]),
        ("h", 2, "2.2 Functional Requirements"),
        b([
            "Accept eight patient measurements plus a patient name and return a risk percentage.",
            "Return an explanation: primary risk factors and protective factors for that patient.",
            "Persist every assessment (patient, vitals, result, timestamp).",
            "Provide a paginated history of past assessments (10 per page).",
            "Validate input and fail gracefully when the ML service is unavailable.",
        ]),
        ("h", 2, "2.3 Non-Functional Requirements"),
        tbl("Non-functional requirements",
            ["Attribute", "Requirement"],
            [["Performance", "Single prediction (model + SHAP) returns in well under one second."],
             ["Scalability", "Stateless gateway and ML service can be replicated horizontally."],
             ["Security", "Input validated and typed; services isolated behind the gateway."],
             ["Privacy", "Only a name and clinical vitals are stored; no sensitive identifiers; "
                         "personal data can be omitted."],
             ["Reliability", "ML outage degrades to a clear 503 message, not a crash."],
             ["Usability", "Single-screen form with sensible defaults and clear risk colouring."]]),
        ("h", 2, "2.4 Technology Stack Selection & Justification"),
        b([
            "Python + FastAPI (ML service): Python is the de-facto ML language; FastAPI gives "
            "typed request validation (Pydantic) and async performance with minimal code.",
            "XGBoost: state-of-the-art on tabular data and — critically — accepts a user-defined "
            "objective function, which the whole project depends on.",
            "SHAP: principled, model-specific (TreeExplainer) per-prediction explanations.",
            "React + Vite + TypeScript (frontend): fast, type-safe SPA development with instant "
            "HMR; Tailwind CSS for rapid, consistent styling.",
            "Node.js + Express (gateway): a lightweight orchestration tier that separates the "
            "public API and persistence from the Python compute, a clean microservice boundary.",
            "MongoDB: schema-flexible document store that maps naturally onto the JSON assessment "
            "records.",
            "Docker Compose: reproducible local MongoDB provisioning.",
        ]),
        ("h", 2, "2.5 Feasibility Analysis"),
        b([
            "Technical: all components are mature open-source tools; the custom objective is a "
            "small, well-understood mathematical addition. Feasible.",
            "Economic: entirely free/open-source; runs on commodity hardware. Feasible.",
            "Operational: simple multi-process local deployment; documented run commands. Feasible.",
            "Legal / Ethical: uses a public anonymised dataset; clearly labelled as a "
            "non-clinical, educational tool. Feasible with disclaimers.",
        ]),
        ("h", 2, "2.6 Risk Analysis & Mitigation"),
        tbl("Risk analysis and mitigation",
            ["Risk", "Impact", "Mitigation"],
            [["ML service down at request time", "No predictions", "Gateway catches ECONNREFUSED "
              "and returns a 503 with a clear message."],
             ["Custom objective unstable / diverges", "Bad model", "Hessian floored at 1e-6; "
              "bounded exponential gradient; verified on held-out folds."],
             ["Probability misinterpreted as calibrated", "Clinical misuse", "Documented as a "
              "risk score; UI/labelling caveat; calibration noted as future work."],
             ["Overfitting / unstable metrics", "Misleading results", "5-fold x 5-seed CV; "
              "mean +/- std reported."]]),
        ("h", 2, "2.7 Project Planning"),
        tbl("Project timeline and milestones",
            ["Phase", "Milestone", "Duration"],
            [["1", "Requirement study, dataset acquisition, baseline XGBoost", "Weeks 1-2"],
             ["2", "Custom objective design & derivation; experiment harness", "Weeks 3-4"],
             ["3", "Distributed system (frontend, gateway, ML service, DB)", "Weeks 5-7"],
             ["4", "Evaluation, figures, deployment & explainability", "Weeks 8-9"],
             ["5", "Report writing & finalisation", "Weeks 10-11"]]),
        pb,
    ]

    # ---- Chapter 3 ----------------------------------------------------------
    B += [
        ("h", 1, "Chapter 3 — System Design & Architecture"),
        ("h", 2, "3.1 Overall System Architecture"),
        p("The system is a four-tier distributed application. The browser SPA never talks to the "
          "ML service directly; all traffic flows through the Node gateway, which orchestrates the "
          "ML call and persistence. This separation is what makes the system 'distributed': each "
          "tier is an independently deployable, independently scalable process."),
        ("code",
         "Browser (React SPA, :5173)\n"
         "        |  POST /api/assess\n"
         "        v\n"
         "Node.js / Express API Gateway (:5000)\n"
         "        |  POST /predict                 \\\n"
         "        v                                  -> MongoDB (:27018)  save record\n"
         "FastAPI ML Engine (:8000)  --XGBoost + SHAP--/\n"),
        ("h", 2, "3.2 Workflow"),
        n([
            "Clinician submits the form; the SPA POSTs name + 8 vitals to /api/assess.",
            "Gateway validates the name, strips it, and relays the 8 vitals to the ML /predict.",
            "ML service applies zero-as-missing, predicts the margin, applies sigmoid, runs SHAP.",
            "Gateway saves {patient, vitals, result} to MongoDB and returns the result to the SPA.",
            "SPA renders the risk percentage with risk/protective factors; History tab reads back "
            "paginated records.",
        ]),
        ("h", 2, "3.3 Database / Data Storage Design"),
        p("A single MongoDB collection, 'predictions', stores one document per assessment "
          "(schema from backend/models/Prediction.js):"),
        tbl("Prediction document schema",
            ["Field", "Type", "Description"],
            [["patientName", "String (required)", "Patient identifier (free text)."],
             ["vitals", "Object", "The eight input measurements."],
             ["result.risk_percentage", "Number", "Cost-sensitive risk score (0-100)."],
             ["result.primary_risk_factors", "String[]", "SHAP-derived risk drivers."],
             ["result.protective_factors", "String[]", "SHAP-derived protective drivers."],
             ["createdAt", "Date", "Timestamp, used for history ordering."]]),
        ("h", 2, "3.4 API / Module Design"),
        tbl("API endpoints",
            ["Method & Path", "Tier", "Purpose"],
            [["POST /api/assess", "Gateway", "Orchestrate prediction + persistence."],
             ["GET /api/history?page=n", "Gateway", "Paginated past assessments (10/page)."],
             ["POST /predict", "ML service", "Risk score + SHAP explanation for 8 vitals."]]),
        ("h", 2, "3.5 UI/UX Design Principles"),
        b([
            "Single-screen assessment form with sensible default vitals to ease trial.",
            "Immediate, colour-coded risk (green/amber/red) and a two-column factor breakdown.",
            "Tabbed navigation between Assess and History; loading and error states everywhere.",
            "'Leave a field at 0 if not measured' guidance, matching the model's missing-value logic.",
        ]),
        ("h", 2, "3.6 Security Design Considerations"),
        b([
            "Strict request typing/validation at both the gateway (name) and ML service (Pydantic).",
            "The ML service is not publicly exposed; only the gateway can reach it.",
            "Minimal data collection; no passwords or sensitive identifiers stored.",
            "CORS controlled at the gateway.",
        ]),
        ("h", 2, "3.7 Deployment Architecture"),
        p("Local/development deployment runs four processes: MongoDB via Docker Compose, the "
          "FastAPI ML service via Uvicorn (:8000), the Node gateway (:5000), and the Vite dev "
          "server (:5173) which proxies /api to the gateway. Each tier can be containerised and "
          "moved to cloud hosts independently for production."),
        pb,
    ]

    # ---- Chapter 4 ----------------------------------------------------------
    B += [
        ("h", 1, "Chapter 4 — Methodology / Model Development"),
        ("h", 2, "4.1 Development Methodology"),
        p("An experimental, iterative methodology was used. The ML core was developed as a "
          "controlled experiment (baseline first, then custom objectives compared under identical "
          "conditions), while the surrounding system was built iteratively, integrating one tier "
          "at a time."),
        ("h", 2, "4.2 Dataset Description"),
        p("The Pima Indians Diabetes dataset (UCI) contains 768 patient records with 8 numeric "
          "features and a binary outcome; 268 patients (~34.9%) are diabetic, giving a moderate "
          "class imbalance. The eight features are Pregnancies, Glucose, BloodPressure, "
          "SkinThickness, Insulin, BMI, Diabetes Pedigree, and Age."),
        ("h", 2, "4.3 Data Preprocessing"),
        p("In five columns (Glucose, BloodPressure, SkinThickness, Insulin, BMI) a recorded value "
          "of 0 is physiologically impossible and actually denotes a missing measurement. These "
          "zeros are converted to NaN. XGBoost handles missing values natively by learning a "
          "default branch direction, so no imputation is performed. Crucially, the identical "
          "transform is applied at serving time so inference sees data exactly as training did."),
        ("h", 2, "4.4 Proposed Algorithm / Model"),
        p("XGBoost is gradient-agnostic: for each sample it needs only the first derivative "
          "(gradient) and second derivative (hessian) of the loss with respect to the raw margin "
          "z, where p = sigmoid(z) and y in {0,1}. We supply three custom objectives. All floor "
          "the hessian at 1e-6 for stability."),
        b([
            "Baseline — standard log-loss: grad = p - y, hess = p(1-p).",
            "(a) Weighted cross-entropy: weight = w if y=1 else 1; grad = weight*(p-y), "
            "hess = weight*p(1-p). We use w = 3.0.",
            "(b) Focal loss (gamma=2, alpha=0.75): FL = -alpha_t*(1-p_t)^gamma*log(p_t); the "
            "(1-p_t)^gamma factor focuses training on hard, misclassified positives.",
            "(c) Exponential false-negative penalty (gamma=2): for positives, "
            "L = exp(gamma*(1-p))*(-log p); the gradient tends to a bounded -exp(gamma) as p->0, "
            "with a Gauss-Newton hessian ~= exp(gamma*(1-p))*p(1-p).",
        ]),
        ("h", 2, "4.5 Tools & Frameworks Used"),
        b([
            "Python 3.14, XGBoost 3.2, scikit-learn 1.8, SHAP 0.51, NumPy 2.4, pandas 3.0, "
            "Matplotlib 3.10, FastAPI + Uvicorn, joblib.",
            "Node.js + Express, Mongoose, Axios; React 19 + Vite + TypeScript + Tailwind CSS; "
            "MongoDB + Docker Compose.",
        ]),
        ("h", 2, "4.6 Training Procedure & Implementation Details"),
        p("Every model shares one hyperparameter set so the loss function is the only variable; "
          "this makes any metric difference causally attributable to the loss."),
        tbl("Shared XGBoost hyperparameters",
            ["Parameter", "Value"],
            [["n_estimators", "200"], ["max_depth", "4"], ["learning_rate", "0.05"],
             ["subsample", "0.8"], ["colsample_bytree", "0.8"], ["reg_lambda", "1.0"],
             ["base_score", "0.5"], ["tree_method", "hist"]]),
        p("Stability protocol: stratified 5-fold cross-validation repeated over 5 seeds "
          "{42,0,7,13,21} = 25 runs per model, reporting mean +/- std. Serving pitfall: with a "
          "custom objective XGBoost's predict_proba is invalid and predict returns the raw "
          "margin, so probability = sigmoid(predict(X, output_margin=True)) is computed manually "
          "everywhere — in the harness and in the live FastAPI service."),
        pb,
    ]

    # ---- Chapter 5 ----------------------------------------------------------
    B += [
        ("h", 1, "Chapter 5 — Implementation & Testing"),
        ("h", 2, "5.1 Module Implementation"),
        b([
            "custom_objectives.py — picklable callable classes for the three losses plus a stable "
            "sigmoid; each carries its grad/hess derivation.",
            "compare_models.py — the experiment harness (CV x seeds, metrics, figures, results "
            "injection).",
            "train_cost_sensitive_model.py — trains the winning objective and saves the deployed "
            "model.",
            "main.py — FastAPI /predict: preprocessing, manual-sigmoid scoring, SHAP explanation.",
            "backend/server.js — Express gateway: /api/assess orchestration and /api/history.",
            "frontend/src/App.tsx — React UI: assess form, result panel, paginated history.",
        ]),
        ("h", 2, "5.2 Integration"),
        p("The tiers integrate over HTTP/JSON. The gateway separates the patient name from the "
          "eight vitals so the ML service receives exactly the fields its Pydantic model "
          "validates, calls the ML service via Axios, persists via Mongoose, and returns a single "
          "packaged response to the SPA, which uses a Vite dev-proxy so the browser uses a "
          "same-origin /api path."),
        ("h", 2, "5.3 Testing Strategy"),
        b([
            "Functional: end-to-end assessment submitted through the API returns a valid score and "
            "is persisted; history pagination verified.",
            "Numerical: gradients/hessians asserted finite with a positive hessian floor; "
            "probabilities asserted within [0,1]; reloaded model re-checked.",
            "Statistical (the thesis test): the harness asserts at least one cost-sensitive model "
            "has higher recall AND fewer false negatives than the baseline, or the run fails.",
            "Performance & usability: sub-second predictions; UI loading/error states exercised.",
        ]),
        ("h", 2, "5.4 Evaluation Metrics"),
        b([
            "Recall / Sensitivity = TP/(TP+FN) — the primary safety metric (catching diabetics).",
            "F2-score — an F-measure weighting recall twice as heavily as precision.",
            "Precision, Specificity, Accuracy — context metrics.",
            "ROC-AUC and PR-AUC — threshold-independent ranking quality.",
            "False-negative count — the raw count of missed diabetics.",
            "Latency — per-prediction response time.",
        ]),
        ("h", 2, "5.5 Error Handling & Edge Cases"),
        b([
            "ML service unreachable -> gateway returns HTTP 503 with a clear message (ECONNREFUSED).",
            "Missing/blank patient name -> HTTP 400 before any ML call.",
            "A 0 in a zero-as-missing field is reported as '(not measured)' rather than a "
            "misleading literal value.",
            "NumPy types cast to native floats so JSON serialisation never fails.",
        ]),
        pb,
    ]

    # ---- Chapter 6 ----------------------------------------------------------
    B += [
        ("h", 1, "Chapter 6 — Results, Analysis & Discussion"),
        ("h", 2, "6.1 Experimental Results"),
        p("All numbers are mean +/- std across 25 runs (5-fold x 5-seed), at decision "
          "threshold 0.5."),
        tbl("Comparison of standard vs. cost-sensitive objectives",
            ["Model", "Recall", "F2", "Precision", "Specificity", "ROC-AUC", "FN/fold"],
            [["Standard", "0.610", "0.620", "0.671", "0.838", "0.826", "20.9"],
             ["Weighted CE", "0.756", "0.720", "0.612", "0.742", "0.827", "13.1"],
             ["Focal (deployed)", "0.770", "0.728", "0.602", "0.725", "0.825", "12.3"],
             ["Exponential", "0.703", "0.686", "0.628", "0.775", "0.821", "15.9"]]),
        ("h", 2, "6.2 Comparison with Existing Methods"),
        p("Against the standard-log-loss XGBoost baseline, the focal objective raises recall from "
          "0.610 to 0.770 and cuts mean false negatives from 20.9 to 12.3 per fold — close to a "
          "halving of missed diabetics — while ROC-AUC is essentially unchanged (0.826 vs 0.825). "
          "The models are therefore not worse; they are re-tuned to a safer operating point on the "
          "same underlying ranking, trading some precision/specificity exactly as intended."),
        ("h", 2, "6.3 Performance Graphs & Figures"),
        fig("roc.png", "ROC curves — all models overlap (AUC ~0.82): discrimination is preserved."),
        fig("pr.png", "Precision-Recall curves; average precision is within noise across models."),
        fig("confusion_grid.png", "Out-of-fold confusion matrices; the red false-negative cell "
            "drops from 102 (Standard) to 57 (Focal)."),
        fig("recall_fn_bars.png", "Mean +/- std recall and false negatives over 25 runs; error "
            "bars do not overlap between Standard and Focal."),
        fig("prob_dist.png", "Predicted-risk distributions; cost-sensitive losses push the "
            "diabetic mass to the right of the 0.5 line."),
        ("h", 2, "6.4 Case Study / Real Usage Scenario"),
        p("Through the live API, a borderline patient (Glucose 145, BMI 33.6, Age 50, Pedigree "
          "0.55) returns a 70.04% risk with Glucose, Pedigree and Age cited as primary risk "
          "factors, whereas a low-risk patient (Glucose 85, BMI 26.6, Age 22) returns 12.34% with "
          "multiple protective factors. The deployed cost-sensitive model flags the borderline "
          "diabetic that the standard model was more likely to miss."),
        ("h", 2, "6.5 Discussion"),
        p("The objectives behave exactly as their gradients predict. One caveat: cost-sensitive "
          "training deliberately inflates positive-class scores, so the served risk_percentage is "
          "a monotonic risk score, appropriate for triage and ranking, not a calibrated "
          "probability. Post-hoc isotonic/Platt calibration would recover calibrated values and "
          "is left as future work."),
        pb,
    ]

    # ---- Chapter 7 ----------------------------------------------------------
    B += [
        ("h", 1, "Chapter 7 — Deployment"),
        ("h", 2, "7.1 Deployment Process"),
        p("Four processes are started in order: the database, the ML service, the gateway, then "
          "the frontend."),
        ("code",
         "# 1. MongoDB\n"
         "docker compose -f backend/docker-compose.yml up -d\n"
         "# 2. ML engine (FastAPI)\n"
         "./venv/bin/uvicorn main:app --port 8000\n"
         "# 3. API gateway (Node)\n"
         "cd backend && node server.js\n"
         "# 4. Frontend (Vite)\n"
         "cd frontend && npm run dev\n"),
        ("h", 2, "7.2 Hardware Requirements"),
        b([
            "Any modern multi-core CPU (no GPU required); ~2 GB RAM is sufficient.",
            "~500 MB disk for dependencies, model, and MongoDB data volume.",
        ]),
        ("h", 2, "7.3 API Endpoints / Usage"),
        tbl("API usage",
            ["Endpoint", "Body / Query", "Returns"],
            [["POST /api/assess", "{patientName, 8 vitals}", "{success, data:{risk_percentage, "
              "explanation}}"],
             ["GET /api/history?page=n", "page number", "{data:[records], pagination}"],
             ["POST /predict (internal)", "{8 vitals}", "{risk_percentage, explanation}"]]),
        ("h", 2, "7.4 Version Control (GitHub Workflow)"),
        b([
            "Feature-branch workflow: develop on branches, open pull requests, review, then merge.",
            "Commits scoped per concern (ML core, gateway, frontend, report).",
        ]),
        ("h", 2, "7.5 Reproducibility Instructions"),
        ("code",
         "# Reproduce the experiment, figures, and results table:\n"
         "./venv/bin/python compare_models.py\n"
         "# Train and deploy the winning cost-sensitive model:\n"
         "./venv/bin/python train_cost_sensitive_model.py\n"
         "# Seeds {42,0,7,13,21}; 5-fold stratified CV; results in results/ and figures/.\n"),
        pb,
    ]

    # ---- Chapter 8 ----------------------------------------------------------
    B += [
        ("h", 1, "Chapter 8 — Conclusion & Future Work"),
        ("h", 2, "8.1 Conclusion"),
        p("Rewriting XGBoost's objective so that false negatives are penalised — linearly "
          "(weighted CE), via hard-example focusing (focal), or exponentially (custom penalty) — "
          "yields a measurably safer diabetes screening model than standard XGBoost, with the "
          "safety gain isolated to the loss function under a controlled, repeated cross-validation "
          "protocol. The winning focal model is deployed inside a complete, explainable, "
          "distributed web application."),
        ("h", 2, "8.2 Limitations"),
        b([
            "Trained and evaluated only on the public Pima cohort; external validity is unproven.",
            "The served score is an uncalibrated risk score, not a literal probability.",
            "Not a certified medical device; for educational/research use only.",
        ]),
        ("h", 2, "8.3 Future Improvements"),
        b([
            "Probability calibration (isotonic/Platt) on a holdout for clinically meaningful "
            "percentages.",
            "Validation on larger, more diverse, real-world clinical datasets.",
            "User authentication and per-clinician patient lists.",
            "Integration with electronic health records and containerised cloud deployment.",
        ]),
        pb,
    ]

    # ---- References ---------------------------------------------------------
    B += [
        ("h", 1, "References"),
        n([
            "T. Chen and C. Guestrin, \"XGBoost: A Scalable Tree Boosting System,\" in Proc. KDD, "
            "2016.",
            "T.-Y. Lin, P. Goyal, R. Girshick, K. He, and P. Dollar, \"Focal Loss for Dense Object "
            "Detection,\" in Proc. ICCV, 2017.",
            "C. Elkan, \"The Foundations of Cost-Sensitive Learning,\" in Proc. IJCAI, 2001.",
            "S. M. Lundberg and S.-I. Lee, \"A Unified Approach to Interpreting Model Predictions "
            "(SHAP),\" in Proc. NeurIPS, 2017.",
            "J. W. Smith et al., \"Using the ADAP learning algorithm to forecast the onset of "
            "diabetes mellitus,\" Proc. SCAMC, 1988 (Pima Indians Diabetes dataset, UCI ML "
            "Repository).",
            "FastAPI documentation, https://fastapi.tiangolo.com.",
            "React documentation, https://react.dev. MongoDB documentation, "
            "https://www.mongodb.com/docs.",
        ]),
        pb,
    ]

    # ---- Appendices ---------------------------------------------------------
    B += [
        ("h", 1, "Appendix A: Project Synopsis"),
        p("A distributed, explainable diabetes-risk screening system whose XGBoost core uses a "
          "custom cost-sensitive loss to minimise false negatives. A 5-fold x 5-seed comparison "
          "shows recall rising from 0.61 to 0.77 and false negatives nearly halving versus "
          "standard XGBoost, with ROC-AUC preserved. The winning model is served in real time with "
          "SHAP explanations behind a React UI, Node gateway, and MongoDB store."),
        ("h", 1, "Appendix B: Research Papers"),
        p("Key papers underpinning this work: Chen & Guestrin (XGBoost, 2016); Lin et al. (Focal "
          "Loss, 2017); Elkan (Cost-Sensitive Learning, 2001); Lundberg & Lee (SHAP, 2017). Full "
          "citations appear in the References section."),
        ("h", 1, "Appendix C: Guide Interaction Report (Mentor Log Book)"),
        tbl("Guide interaction log",
            ["Date", "Discussion Summary", "Guide Signature"],
            [["<<date>>", "<<summary>>", ""],
             ["<<date>>", "<<summary>>", ""],
             ["<<date>>", "<<summary>>", ""]]),
        ("h", 1, "Appendix D: User Manual & Installation Guide"),
        p("Installation and run steps:"),
        ("code",
         "# Python ML environment\n"
         "python -m venv venv && ./venv/bin/pip install fastapi uvicorn xgboost shap \\\n"
         "    scikit-learn pandas numpy matplotlib joblib\n"
         "# Train/deploy the model\n"
         "./venv/bin/python train_cost_sensitive_model.py\n"
         "# Start the four services (see Chapter 7.1)\n"
         "docker compose -f backend/docker-compose.yml up -d\n"
         "./venv/bin/uvicorn main:app --port 8000\n"
         "cd backend && npm install && node server.js\n"
         "cd frontend && npm install && npm run dev\n"),
        p("Usage: open the Vite URL, enter a patient name and the eight vitals (leave a field at 0 "
          "if not measured), and click Assess Risk. The History tab lists past assessments."),
        ("h", 1, "Appendix E: Git / GitHub Commit History"),
        p("The project is version-controlled with Git using a feature-branch + pull-request "
          "workflow. The full commit history (authors, dates, messages) is available in the "
          "repository hosting (<<repository URL>>)."),
    ]
    return B


# ===========================================================================
# Front-matter text (shared)
# ===========================================================================
DECLARATION = (
    "We hereby declare that the work, which is being presented in the project entitled "
    f"“{TITLE}” in partial fulfillment of the requirement for the award of the degree of "
    "Bachelor of Technology, submitted in the Department of Information Technology / Computer "
    "Science & Engineering (Data Science) at Acropolis Institute of Technology & Research, Indore "
    "is an authentic record of our own work carried out under the supervision of "
    "“Prof./Dr. <<Project Guide>>”. We have not submitted the matter embodied in this "
    "report for the award of any other degree.")

APPROVAL = (
    f"I hereby recommend that the project “{TITLE}” prepared under my supervision by "
    "<<Student Name (Roll No.)>> be accepted in partial fulfillment of the requirement for the "
    "degree of Bachelor of Technology in Information Technology / Computer Science & Engineering "
    "(Data Science).")

CERTIFICATE = (
    f"The project work entitled “{TITLE}” submitted by <<Name of the student (Enrollment "
    "No)>> is approved as partial fulfillment for the award of the degree of Bachelor of "
    "Technology in Information Technology / Computer Science & Engineering (Data Science) by Rajiv "
    "Gandhi Proudyogiki Vishwavidyalaya, Bhopal (M.P.).")

ACK = [
    "With boundless love and appreciation, we would like to extend our heartfelt gratitude and "
    "appreciation to the people who helped us bring this work to reality.",
    "Foremost, we would like to express our sincere gratitude to our supervisor, "
    "Prof./Dr. <<Project Guide>>, whose expertise, consistent guidance, ample time spent and "
    "advice helped us bring this study to success.",
    "To the project in-charge Prof. <<Name of Incharge>> and project coordinator "
    "Prof. Deepak Singh Chouhan for their constructive comments, suggestions, and critiquing.",
    "To the honorable Prof. (Dr.) Prashant Lakkadwala, Head, Department of Information Technology / "
    "Computer Science & Engineering (Data Science), for his favorable responses and for providing "
    "the necessary facilities.",
    "To the honorable Dr. S.C. Sharma, Director, AITR, Indore, for his unending support, advice "
    "and effort to make this possible.",
    "Finally, we would like to thank the faculty members and staff of the department, and our "
    "parents, for their eternal love, support and prayers.",
]

ABSTRACT = (
    "This project presents a Distributed Diabetes Risk Assessment System that reframes diabetes "
    "screening as a cost-sensitive learning problem. In screening, a false negative (a missed "
    "diabetic) is far more harmful than a false positive (an unnecessary confirmatory test), yet "
    "standard machine-learning models minimise a symmetric loss that ignores this asymmetry. We "
    "address this by replacing the standard log-loss objective of the XGBoost classifier with "
    "custom objective functions whose gradients make missed positives substantially more "
    "expensive. Three objectives were designed and analytically derived: a weighted cross-entropy, "
    "a focal loss, and a bespoke exponential false-negative penalty, each supplying XGBoost with a "
    "purpose-built gradient and a numerically stable hessian. The work was carried out as a "
    "controlled experiment on the Pima Indians Diabetes dataset using stratified five-fold "
    "cross-validation repeated over five random seeds, holding every hyperparameter fixed so that "
    "the loss function is the only variable. The winning model is deployed inside a four-tier "
    "distributed application comprising a React interface, a Node.js API gateway, a Python FastAPI "
    "machine-learning microservice, and a MongoDB store, with SHAP providing a transparent "
    "per-patient explanation of risk and protective factors. A key engineering subtlety was also "
    "addressed: because a custom objective leaves XGBoost without a link function, the raw margin "
    "output must be passed through a sigmoid manually at serving time, a step handled consistently "
    "across both the experiment and the live service. The cost-sensitive objectives raised "
    "recall (sensitivity) from 0.61 to 0.77 and nearly halved the number of false negatives, "
    "reducing missed diabetics from roughly 21 to 12 per validation fold, while leaving ranking "
    "quality (ROC-AUC about 0.82) essentially unchanged; the modest cost was a controlled drop in "
    "precision and specificity, exactly the trade a screening tool should make. This demonstrates "
    "that the improvement is a deliberate, safer operating point rather than a degraded model, "
    "achieved by mathematical tuning of the learning objective itself rather than by resampling or "
    "threshold heuristics. The significance is a practical, explainable, and reproducible blueprint "
    "for building screening tools whose mathematics encode real clinical cost, prioritising patient "
    "safety over raw accuracy.")

KEYWORDS = ("Cost-Sensitive Learning, XGBoost, Custom Loss Function, Diabetes Screening, "
            "False Negative, Explainable AI (SHAP), Distributed System")

ABBREVIATIONS = [
    ("AI", "Artificial Intelligence"), ("API", "Application Programming Interface"),
    ("AUC", "Area Under the Curve"), ("BMI", "Body Mass Index"),
    ("CV", "Cross-Validation"), ("FN", "False Negative"), ("FP", "False Positive"),
    ("ML", "Machine Learning"), ("PR", "Precision-Recall"),
    ("REST", "Representational State Transfer"), ("ROC", "Receiver Operating Characteristic"),
    ("SHAP", "SHapley Additive exPlanations"), ("SPA", "Single-Page Application"),
    ("TN", "True Negative"), ("TP", "True Positive"), ("UI/UX", "User Interface / Experience"),
    ("XGBoost", "Extreme Gradient Boosting"),
]


# ===========================================================================
# DOCX renderer
# ===========================================================================
class DocxRenderer:
    def __init__(self):
        self.doc = Document()
        st = self.doc.styles["Normal"]
        st.font.name = "Calibri"
        st.font.size = Pt(11)

    def _center(self, text, bold=False, size=None):
        para = self.doc.add_paragraph()
        para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = para.add_run(text)
        run.bold = bold
        if size:
            run.font.size = Pt(size)
        return para

    def cover(self):
        if os.path.exists(LOGO):
            p = self.doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.add_run().add_picture(LOGO, width=Inches(3.2))
        self.doc.add_paragraph()
        self._center(TITLE.upper(), bold=True, size=22)
        self.doc.add_paragraph()
        self._center("A Project Report", size=14)
        self._center("Submitted in partial fulfillment of the requirement for the award of "
                     "the degree of", size=11)
        self._center("Bachelor of Technology", bold=True, size=13)
        self._center("in", size=11)
        self._center("Information Technology / Computer Science & Engineering (Data Science)",
                     size=11)
        self.doc.add_paragraph()
        self._center("Submitted to", size=11)
        self._center("RAJIV GANDHI PROUDYOGIKI VISHWAVIDYALAYA, BHOPAL (M.P.)", bold=True, size=12)
        self.doc.add_paragraph()
        guide = self.doc.add_paragraph()
        guide.add_run("Guided By:\t\tProf./Dr. <<Project Guide>>\n")
        guide.add_run("Submitted By:\t<<Student Name 1 (Roll No)>>\n"
                      "\t\t\t<<Student Name 2 (Roll No)>>\n"
                      "\t\t\t<<Student Name 3 (Roll No)>>\n"
                      "\t\t\t<<Student Name 4 (Roll No)>>")
        self.doc.add_paragraph()
        self._center("DEPARTMENT OF INFORMATION TECHNOLOGY / CSE(DS)", bold=True, size=12)
        self._center("ACROPOLIS INSTITUTE OF TECHNOLOGY & RESEARCH, INDORE (M.P.) 453771",
                     bold=True, size=12)
        self._center(SESSION, bold=True, size=12)
        self.doc.add_page_break()

    def section(self, heading, paras, signoff=None):
        self.doc.add_heading(heading, level=1)
        for para in paras:
            self.doc.add_paragraph(para)
        if signoff:
            self.doc.add_paragraph()
            for line in signoff:
                self._center(line)
        self.doc.add_page_break()

    def abstract(self):
        self.doc.add_heading("Abstract", level=1)
        self.doc.add_paragraph(ABSTRACT)
        kp = self.doc.add_paragraph()
        kp.add_run("Keywords: ").bold = True
        kp.add_run(KEYWORDS)
        self.doc.add_page_break()

    def simple_list_page(self, title, entries):
        # entries: list of (label, text)
        self.doc.add_heading(title, level=1)
        for label, text in entries:
            para = self.doc.add_paragraph()
            para.add_run(f"{label} ").bold = True
            para.add_run(text)
        self.doc.add_page_break()

    def abbreviations(self):
        self.doc.add_heading("Abbreviations", level=1)
        table = self.doc.add_table(rows=1, cols=2)
        table.style = "Light Grid Accent 1"
        hdr = table.rows[0].cells
        hdr[0].paragraphs[0].add_run("Abbreviation").bold = True
        hdr[1].paragraphs[0].add_run("Full Form").bold = True
        for abbr, full in ABBREVIATIONS:
            row = table.add_row().cells
            row[0].text = abbr
            row[1].text = full
        self.doc.add_page_break()

    def toc(self):
        self.doc.add_heading("Table of Contents", level=1)
        items = ["Declaration", "Project Approval Form", "Certificate", "Acknowledgement",
                 "Abstract", "List of Figures", "List of Tables", "Abbreviations",
                 "Chapter 1 — Introduction & Background",
                 "Chapter 2 — Requirements & Planning",
                 "Chapter 3 — System Design & Architecture",
                 "Chapter 4 — Methodology / Model Development",
                 "Chapter 5 — Implementation & Testing",
                 "Chapter 6 — Results, Analysis & Discussion",
                 "Chapter 7 — Deployment",
                 "Chapter 8 — Conclusion & Future Work",
                 "References", "Appendices A-E"]
        for it in items:
            para = self.doc.add_paragraph(it)
            para.paragraph_format.space_after = Pt(2)
        self.doc.add_page_break()

    def render_block(self, block):
        kind = block[0]
        if kind == "h":
            self.doc.add_heading(block[2], level=block[1])
        elif kind == "p":
            self.doc.add_paragraph(block[1])
        elif kind == "b":
            for item in block[1]:
                self.doc.add_paragraph(item, style="List Bullet")
        elif kind == "n":
            for item in block[1]:
                self.doc.add_paragraph(item, style="List Number")
        elif kind == "code":
            para = self.doc.add_paragraph()
            run = para.add_run(block[1])
            run.font.name = "Consolas"
            run.font.size = Pt(9)
        elif kind == "tbl":
            caption, headers, rows = block[1], block[2], block[3]
            cap = self.doc.add_paragraph()
            cap.add_run(caption).italic = True
            table = self.doc.add_table(rows=1, cols=len(headers))
            table.style = "Light Grid Accent 1"
            for i, head in enumerate(headers):
                table.rows[0].cells[i].paragraphs[0].add_run(head).bold = True
            for r in rows:
                cells = table.add_row().cells
                for i, val in enumerate(r):
                    cells[i].text = str(val)
        elif kind == "fig":
            path = os.path.join(FIG, block[1])
            if os.path.exists(path):
                pic = self.doc.add_paragraph()
                pic.alignment = WD_ALIGN_PARAGRAPH.CENTER
                pic.add_run().add_picture(path, width=Inches(5.3))
            cap = self.doc.add_paragraph()
            cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
            cap.add_run(block[2]).italic = True
        elif kind == "pb":
            self.doc.add_page_break()

    def list_of_figures(self):
        self.simple_list_page("List of Figures",
                              [(lbl, cap) for lbl, cap in FIGURES])

    def list_of_tables(self):
        self.simple_list_page("List of Tables",
                              [(lbl, cap) for lbl, cap in TABLES])

    def build(self, body):
        self.cover()
        self.section("Declaration", [DECLARATION],
                     signoff=["<<Student Name>> <<Roll No>>", "",
                              "Prof./Dr. <<Project Guide>> (Supervisor)"])
        self.section("Project Approval Form", [APPROVAL],
                     signoff=["<<Supervisor Name>> (Supervisor)",
                              f"Recommendation concurred in {SESSION}",
                              "<<Name>> (Project Incharge)",
                              "Prof. Deepak Singh Chouhan (Project Coordinator)"])
        self.section("Certificate", [CERTIFICATE],
                     signoff=["Internal Examiner\t\t\tExternal Examiner",
                              "Name: ................\t\tName: ................",
                              "Date: ..../..../........\t\tDate: ..../..../........"])
        self.section("Acknowledgement", ACK,
                     signoff=["<<Student 1 (Roll No)>>", "<<Student 2 (Roll No)>>",
                              "<<Student 3 (Roll No)>>", "<<Student 4 (Roll No)>>"])
        self.abstract()
        self.toc()
        self.list_of_figures()
        self.list_of_tables()
        self.abbreviations()
        for block in body:
            self.render_block(block)
        self.doc.save(DOCX_OUT)


# ===========================================================================
# Markdown renderer
# ===========================================================================
class MdRenderer:
    def __init__(self):
        self.lines = []

    def w(self, s=""):
        self.lines.append(s)

    def block(self, block):
        kind = block[0]
        if kind == "h":
            self.w(); self.w("#" * (block[1] + 1) + " " + block[2]); self.w()
        elif kind == "p":
            self.w(block[1]); self.w()
        elif kind == "b":
            for item in block[1]:
                self.w(f"- {item}")
            self.w()
        elif kind == "n":
            for i, item in enumerate(block[1], 1):
                self.w(f"{i}. {item}")
            self.w()
        elif kind == "code":
            self.w("```"); self.w(block[1].rstrip("\n")); self.w("```"); self.w()
        elif kind == "tbl":
            caption, headers, rows = block[1], block[2], block[3]
            self.w(f"*{caption}*"); self.w()
            self.w("| " + " | ".join(headers) + " |")
            self.w("|" + "---|" * len(headers))
            for r in rows:
                self.w("| " + " | ".join(str(c) for c in r) + " |")
            self.w()
        elif kind == "fig":
            self.w(f"![{block[2]}](figures/{block[1]})"); self.w(); self.w(f"*{block[2]}*"); self.w()
        elif kind == "pb":
            self.w("---"); self.w()

    def build(self, body):
        self.w(f"# {TITLE}")
        self.w()
        self.w("**A Project Report** submitted in partial fulfillment of the requirement for the "
               "award of the degree of **Bachelor of Technology** in Information Technology / "
               "Computer Science & Engineering (Data Science).")
        self.w()
        self.w("Submitted to **Rajiv Gandhi Proudyogiki Vishwavidyalaya, Bhopal (M.P.)** | "
               "Acropolis Institute of Technology & Research, Indore (M.P.) | " + SESSION)
        self.w()
        self.w("| | |")
        self.w("|---|---|")
        self.w("| **Guided By** | Prof./Dr. <<Project Guide>> |")
        self.w("| **Submitted By** | <<Student Name 1 (Roll No)>>, <<Student Name 2 (Roll No)>>, "
               "<<Student Name 3 (Roll No)>>, <<Student Name 4 (Roll No)>> |")
        self.w(); self.w("---"); self.w()
        # Declaration / Approval / Certificate / Acknowledgement
        self.w("## Declaration"); self.w(); self.w(DECLARATION); self.w()
        self.w("_<<Student Name>> <<Roll No>> — Prof./Dr. <<Project Guide>> (Supervisor)_"); self.w()
        self.w("---"); self.w()
        self.w("## Project Approval Form"); self.w(); self.w(APPROVAL); self.w()
        self.w("_<<Supervisor Name>> (Supervisor) · Prof. Deepak Singh Chouhan (Project "
               "Coordinator)_"); self.w(); self.w("---"); self.w()
        self.w("## Certificate"); self.w(); self.w(CERTIFICATE); self.w()
        self.w("_Internal Examiner / External Examiner — Name & Date: ................_")
        self.w(); self.w("---"); self.w()
        self.w("## Acknowledgement"); self.w()
        for a in ACK:
            self.w(a); self.w()
        self.w("_<<Student 1>>, <<Student 2>>, <<Student 3>>, <<Student 4>>_")
        self.w(); self.w("---"); self.w()
        # Abstract
        self.w("## Abstract"); self.w(); self.w(ABSTRACT); self.w()
        self.w(f"**Keywords:** {KEYWORDS}"); self.w(); self.w("---"); self.w()
        # Lists
        self.w("## List of Figures"); self.w()
        for lbl, cap in FIGURES:
            self.w(f"- **{lbl}** {cap}")
        self.w(); self.w("## List of Tables"); self.w()
        for lbl, cap in TABLES:
            self.w(f"- **{lbl}** {cap}")
        self.w(); self.w("## Abbreviations"); self.w()
        self.w("| Abbreviation | Full Form |"); self.w("|---|---|")
        for abbr, full in ABBREVIATIONS:
            self.w(f"| {abbr} | {full} |")
        self.w(); self.w("---"); self.w()
        # Body
        for block in body:
            self.block(block)
        with open(MD_OUT, "w") as f:
            f.write("\n".join(self.lines) + "\n")


# ===========================================================================
def main():
    body = body_blocks()  # populates FIGURES/TABLES registries

    MdRenderer().build(body)
    DocxRenderer().build(body)

    # ---- Verification ----
    doc = Document(DOCX_OUT)
    headings = [p.text for p in doc.paragraphs if p.style.name.startswith("Heading 1")]
    n_images = len(doc.inline_shapes)
    n_tables = len(doc.tables)
    words = len(ABSTRACT.split())
    assert 300 <= words <= 350, f"Abstract is {words} words (need 300-350)"
    for ch in range(1, 9):
        assert any(f"Chapter {ch}" in h for h in headings), f"Missing Chapter {ch}"
    assert n_images >= 6, f"Expected logo + 5 figures embedded, got {n_images}"

    print("Report generated successfully.")
    print(f"  DOCX : {DOCX_OUT}")
    print(f"  MD   : {MD_OUT}")
    print(f"  Heading-1 sections : {len(headings)}")
    print(f"  Embedded images    : {n_images} (logo + {len(FIGURES)} figures)")
    print(f"  Tables             : {n_tables}")
    print(f"  Abstract words     : {words} (target 300-350)")


if __name__ == "__main__":
    main()
