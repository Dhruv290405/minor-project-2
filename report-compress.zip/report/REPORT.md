# Distributed Diabetes Risk Assessment System

**A Project Report** submitted in partial fulfillment of the requirement for the award of the degree of **Bachelor of Technology** in Information Technology / Computer Science & Engineering (Data Science).

Submitted to **Rajiv Gandhi Proudyogiki Vishwavidyalaya, Bhopal (M.P.)** | Acropolis Institute of Technology & Research, Indore (M.P.) | 2025-2026

| | |
|---|---|
| **Guided By** | Prof./Dr. <<Project Guide>> |
| **Submitted By** | <<Student Name 1 (Roll No)>>, <<Student Name 2 (Roll No)>>, <<Student Name 3 (Roll No)>>, <<Student Name 4 (Roll No)>> |

---

## Declaration

We hereby declare that the work, which is being presented in the project entitled “Distributed Diabetes Risk Assessment System” in partial fulfillment of the requirement for the award of the degree of Bachelor of Technology, submitted in the Department of Information Technology / Computer Science & Engineering (Data Science) at Acropolis Institute of Technology & Research, Indore is an authentic record of our own work carried out under the supervision of “Prof./Dr. <<Project Guide>>”. We have not submitted the matter embodied in this report for the award of any other degree.

_<<Student Name>> <<Roll No>> — Prof./Dr. <<Project Guide>> (Supervisor)_

---

## Project Approval Form

I hereby recommend that the project “Distributed Diabetes Risk Assessment System” prepared under my supervision by <<Student Name (Roll No.)>> be accepted in partial fulfillment of the requirement for the degree of Bachelor of Technology in Information Technology / Computer Science & Engineering (Data Science).

_<<Supervisor Name>> (Supervisor) · Prof. Deepak Singh Chouhan (Project Coordinator)_

---

## Certificate

The project work entitled “Distributed Diabetes Risk Assessment System” submitted by <<Name of the student (Enrollment No)>> is approved as partial fulfillment for the award of the degree of Bachelor of Technology in Information Technology / Computer Science & Engineering (Data Science) by Rajiv Gandhi Proudyogiki Vishwavidyalaya, Bhopal (M.P.).

_Internal Examiner / External Examiner — Name & Date: ................_

---

## Acknowledgement

With boundless love and appreciation, we would like to extend our heartfelt gratitude and appreciation to the people who helped us bring this work to reality.

Foremost, we would like to express our sincere gratitude to our supervisor, Prof./Dr. <<Project Guide>>, whose expertise, consistent guidance, ample time spent and advice helped us bring this study to success.

To the project in-charge Prof. <<Name of Incharge>> and project coordinator Prof. Deepak Singh Chouhan for their constructive comments, suggestions, and critiquing.

To the honorable Prof. (Dr.) Prashant Lakkadwala, Head, Department of Information Technology / Computer Science & Engineering (Data Science), for his favorable responses and for providing the necessary facilities.

To the honorable Dr. S.C. Sharma, Director, AITR, Indore, for his unending support, advice and effort to make this possible.

Finally, we would like to thank the faculty members and staff of the department, and our parents, for their eternal love, support and prayers.

_<<Student 1>>, <<Student 2>>, <<Student 3>>, <<Student 4>>_

---

## Abstract

This project presents a Distributed Diabetes Risk Assessment System that reframes diabetes screening as a cost-sensitive learning problem. In screening, a false negative (a missed diabetic) is far more harmful than a false positive (an unnecessary confirmatory test), yet standard machine-learning models minimise a symmetric loss that ignores this asymmetry. We address this by replacing the standard log-loss objective of the XGBoost classifier with custom objective functions whose gradients make missed positives substantially more expensive. Three objectives were designed and analytically derived: a weighted cross-entropy, a focal loss, and a bespoke exponential false-negative penalty, each supplying XGBoost with a purpose-built gradient and a numerically stable hessian. The work was carried out as a controlled experiment on the Pima Indians Diabetes dataset using stratified five-fold cross-validation repeated over five random seeds, holding every hyperparameter fixed so that the loss function is the only variable. The winning model is deployed inside a four-tier distributed application comprising a React interface, a Node.js API gateway, a Python FastAPI machine-learning microservice, and a MongoDB store, with SHAP providing a transparent per-patient explanation of risk and protective factors. A key engineering subtlety was also addressed: because a custom objective leaves XGBoost without a link function, the raw margin output must be passed through a sigmoid manually at serving time, a step handled consistently across both the experiment and the live service. The cost-sensitive objectives raised recall (sensitivity) from 0.61 to 0.77 and nearly halved the number of false negatives, reducing missed diabetics from roughly 21 to 12 per validation fold, while leaving ranking quality (ROC-AUC about 0.82) essentially unchanged; the modest cost was a controlled drop in precision and specificity, exactly the trade a screening tool should make. This demonstrates that the improvement is a deliberate, safer operating point rather than a degraded model, achieved by mathematical tuning of the learning objective itself rather than by resampling or threshold heuristics. The significance is a practical, explainable, and reproducible blueprint for building screening tools whose mathematics encode real clinical cost, prioritising patient safety over raw accuracy.

**Keywords:** Cost-Sensitive Learning, XGBoost, Custom Loss Function, Diabetes Screening, False Negative, Explainable AI (SHAP), Distributed System

---

## List of Figures

- **Figure 1** ROC curves — all models overlap (AUC ~0.82): discrimination is preserved.
- **Figure 2** Precision-Recall curves; average precision is within noise across models.
- **Figure 3** Out-of-fold confusion matrices; the red false-negative cell drops from 102 (Standard) to 57 (Focal).
- **Figure 4** Mean +/- std recall and false negatives over 25 runs; error bars do not overlap between Standard and Focal.
- **Figure 5** Predicted-risk distributions; cost-sensitive losses push the diabetic mass to the right of the 0.5 line.

## List of Tables

- **Table 1** Non-functional requirements
- **Table 2** Risk analysis and mitigation
- **Table 3** Project timeline and milestones
- **Table 4** Prediction document schema
- **Table 5** API endpoints
- **Table 6** Shared XGBoost hyperparameters
- **Table 7** Comparison of standard vs. cost-sensitive objectives
- **Table 8** API usage
- **Table 9** Guide interaction log

## Abbreviations

| Abbreviation | Full Form |
|---|---|
| AI | Artificial Intelligence |
| API | Application Programming Interface |
| AUC | Area Under the Curve |
| BMI | Body Mass Index |
| CV | Cross-Validation |
| FN | False Negative |
| FP | False Positive |
| ML | Machine Learning |
| PR | Precision-Recall |
| REST | Representational State Transfer |
| ROC | Receiver Operating Characteristic |
| SHAP | SHapley Additive exPlanations |
| SPA | Single-Page Application |
| TN | True Negative |
| TP | True Positive |
| UI/UX | User Interface / Experience |
| XGBoost | Extreme Gradient Boosting |

---


## Chapter 1 — Introduction & Background


### 1.1 Problem Context (Real-world Scenario)

Diabetes mellitus is one of the fastest-growing chronic diseases worldwide, and a large fraction of cases — especially Type-2 — remain undiagnosed for years. In a screening setting (a community health camp, a primary-care clinic, or a tele-health portal), a low-cost predictive test is used to decide which patients should be sent for confirmatory laboratory diagnosis. The defining characteristic of this domain is that the two possible errors are NOT equally harmful. A false negative — telling a diabetic patient that they are healthy — sends a genuinely sick person home with no follow-up, allowing the disease to progress untreated. A false positive — flagging a healthy person for a blood test that turns out negative — costs only the price and inconvenience of that test. In clinical screening the false negative is the dangerous, expensive error.


### 1.2 Motivation & Need

Standard machine-learning classifiers, including gradient-boosted trees, are trained to minimise a symmetric loss (log-loss) that treats both error types as equally bad. On a class-imbalanced screening dataset this quietly maximises overall accuracy while accepting a high rate of missed diabetics. A safe screening tool must instead be explicitly biased toward sensitivity (recall). This project is motivated by the need for a diagnostic aid whose mathematics encode the real clinical cost of a missed diagnosis, while remaining transparent (explainable) to the clinician using it.


### 1.3 Why Current Solutions Are Insufficient

- Most published diabetes-prediction models optimise accuracy or AUC and report those as success metrics, hiding a poor false-negative rate.
- Class-imbalance is often handled only by resampling (SMOTE) or the single scale_pos_weight knob, rather than a purpose-built cost-sensitive loss.
- Many models are 'black boxes' offered without per-prediction explanations, which clinicians cannot trust or act on.
- Research prototypes are frequently single scripts, not deployable, distributed systems with a usable interface and persistent record-keeping.


### 1.4 Literature Review / Existing Solutions

- Chen & Guestrin (2016), XGBoost — the scalable gradient-boosting framework used here; natively supports user-defined objective functions.
- Lin et al. (2017), Focal Loss — introduces the (1-p)^gamma modulating factor that focuses training on hard examples; adapted in this work as a cost-sensitive objective.
- Elkan (2001), The Foundations of Cost-Sensitive Learning — formalises learning when error costs are asymmetric.
- Lundberg & Lee (2017), SHAP — game-theoretic per-feature attributions, used here to explain every individual risk score.
- Smith et al. (1988) and the UCI Pima Indians Diabetes dataset — the standard benchmark used for evaluation; existing studies on it rarely target the false-negative rate.


### 1.5 Problem Statement

Given the eight standard diagnostic measurements of a patient, predict the risk of diabetes such that the number of false negatives (missed diabetics) is minimised without materially degrading the model's ranking ability (ROC-AUC), and deliver this prediction — together with a human-readable explanation — through a reliable, distributed web application that persists every assessment.


### 1.6 Proposed Solution Overview

We build a four-tier distributed system: a React single-page interface, a Node.js/Express API gateway, a Python/FastAPI machine-learning microservice, and a MongoDB store. The ML core replaces XGBoost's standard log-loss with a custom, cost-sensitive objective function whose gradient makes a missed diabetic far more expensive than a false alarm. SHAP produces a per-patient breakdown of risk and protective factors.


### 1.7 Objectives

- Design and implement three custom XGBoost objective functions (weighted cross-entropy, focal loss, exponential false-negative penalty) with analytically derived gradient and hessian.
- Demonstrate, under a repeated cross-validation protocol, a statistically stable increase in recall and reduction in false negatives versus standard XGBoost.
- Preserve ranking quality (ROC-AUC) so the gain is a safer operating point, not a worse model.
- Serve the winning model in real time with per-prediction SHAP explanations.
- Persist every assessment and expose a paginated history.


### 1.8 Contributions

- A purpose-built exponential false-negative loss for XGBoost, with a bounded gradient and a stable Gauss-Newton hessian approximation.
- A controlled, reproducible comparison (5-fold x 5-seed) isolating the loss function as the only variable.
- A complete, deployable distributed system around the model, not just a notebook.
- Identification and correct handling of the custom-objective serving pitfall (manual sigmoid on raw margins).


### 1.9 Scope & Limitations

Scope: tabular risk screening on the eight Pima features, an explainable real-time API, and a web UI with history. Limitations: the model is trained on the public Pima cohort (adult female patients of Pima heritage) and is a research/educational artifact, not a certified medical device; cost-sensitive training deliberately produces an uncalibrated risk score rather than a literal probability.


### 1.10 Organization of Report

Chapter 2 covers requirements and planning; Chapter 3 the system design and architecture; Chapter 4 the methodology and model development; Chapter 5 implementation and testing; Chapter 6 results, analysis and discussion; Chapter 7 deployment; and Chapter 8 the conclusion and future work, followed by references and appendices.

---


## Chapter 2 — Requirements & Planning


### 2.1 Stakeholders & Users

- Screening clinicians / health-camp staff — primary users who enter patient vitals and read the risk score and explanation.
- Patients — the subjects of the assessment, indirectly served by safer triage.
- Administrators / researchers — review the stored history and model behaviour.


### 2.2 Functional Requirements

- Accept eight patient measurements plus a patient name and return a risk percentage.
- Return an explanation: primary risk factors and protective factors for that patient.
- Persist every assessment (patient, vitals, result, timestamp).
- Provide a paginated history of past assessments (10 per page).
- Validate input and fail gracefully when the ML service is unavailable.


### 2.3 Non-Functional Requirements

*Table 1: Non-functional requirements*

| Attribute | Requirement |
|---|---|
| Performance | Single prediction (model + SHAP) returns in well under one second. |
| Scalability | Stateless gateway and ML service can be replicated horizontally. |
| Security | Input validated and typed; services isolated behind the gateway. |
| Privacy | Only a name and clinical vitals are stored; no sensitive identifiers; personal data can be omitted. |
| Reliability | ML outage degrades to a clear 503 message, not a crash. |
| Usability | Single-screen form with sensible defaults and clear risk colouring. |


### 2.4 Technology Stack Selection & Justification

- Python + FastAPI (ML service): Python is the de-facto ML language; FastAPI gives typed request validation (Pydantic) and async performance with minimal code.
- XGBoost: state-of-the-art on tabular data and — critically — accepts a user-defined objective function, which the whole project depends on.
- SHAP: principled, model-specific (TreeExplainer) per-prediction explanations.
- React + Vite + TypeScript (frontend): fast, type-safe SPA development with instant HMR; Tailwind CSS for rapid, consistent styling.
- Node.js + Express (gateway): a lightweight orchestration tier that separates the public API and persistence from the Python compute, a clean microservice boundary.
- MongoDB: schema-flexible document store that maps naturally onto the JSON assessment records.
- Docker Compose: reproducible local MongoDB provisioning.


### 2.5 Feasibility Analysis

- Technical: all components are mature open-source tools; the custom objective is a small, well-understood mathematical addition. Feasible.
- Economic: entirely free/open-source; runs on commodity hardware. Feasible.
- Operational: simple multi-process local deployment; documented run commands. Feasible.
- Legal / Ethical: uses a public anonymised dataset; clearly labelled as a non-clinical, educational tool. Feasible with disclaimers.


### 2.6 Risk Analysis & Mitigation

*Table 2: Risk analysis and mitigation*

| Risk | Impact | Mitigation |
|---|---|---|
| ML service down at request time | No predictions | Gateway catches ECONNREFUSED and returns a 503 with a clear message. |
| Custom objective unstable / diverges | Bad model | Hessian floored at 1e-6; bounded exponential gradient; verified on held-out folds. |
| Probability misinterpreted as calibrated | Clinical misuse | Documented as a risk score; UI/labelling caveat; calibration noted as future work. |
| Overfitting / unstable metrics | Misleading results | 5-fold x 5-seed CV; mean +/- std reported. |


### 2.7 Project Planning

*Table 3: Project timeline and milestones*

| Phase | Milestone | Duration |
|---|---|---|
| 1 | Requirement study, dataset acquisition, baseline XGBoost | Weeks 1-2 |
| 2 | Custom objective design & derivation; experiment harness | Weeks 3-4 |
| 3 | Distributed system (frontend, gateway, ML service, DB) | Weeks 5-7 |
| 4 | Evaluation, figures, deployment & explainability | Weeks 8-9 |
| 5 | Report writing & finalisation | Weeks 10-11 |

---


## Chapter 3 — System Design & Architecture


### 3.1 Overall System Architecture

The system is a four-tier distributed application. The browser SPA never talks to the ML service directly; all traffic flows through the Node gateway, which orchestrates the ML call and persistence. This separation is what makes the system 'distributed': each tier is an independently deployable, independently scalable process.

```
Browser (React SPA, :5173)
        |  POST /api/assess
        v
Node.js / Express API Gateway (:5000)
        |  POST /predict                 \
        v                                  -> MongoDB (:27018)  save record
FastAPI ML Engine (:8000)  --XGBoost + SHAP--/
```


### 3.2 Workflow

1. Clinician submits the form; the SPA POSTs name + 8 vitals to /api/assess.
2. Gateway validates the name, strips it, and relays the 8 vitals to the ML /predict.
3. ML service applies zero-as-missing, predicts the margin, applies sigmoid, runs SHAP.
4. Gateway saves {patient, vitals, result} to MongoDB and returns the result to the SPA.
5. SPA renders the risk percentage with risk/protective factors; History tab reads back paginated records.


### 3.3 Database / Data Storage Design

A single MongoDB collection, 'predictions', stores one document per assessment (schema from backend/models/Prediction.js):

*Table 4: Prediction document schema*

| Field | Type | Description |
|---|---|---|
| patientName | String (required) | Patient identifier (free text). |
| vitals | Object | The eight input measurements. |
| result.risk_percentage | Number | Cost-sensitive risk score (0-100). |
| result.primary_risk_factors | String[] | SHAP-derived risk drivers. |
| result.protective_factors | String[] | SHAP-derived protective drivers. |
| createdAt | Date | Timestamp, used for history ordering. |


### 3.4 API / Module Design

*Table 5: API endpoints*

| Method & Path | Tier | Purpose |
|---|---|---|
| POST /api/assess | Gateway | Orchestrate prediction + persistence. |
| GET /api/history?page=n | Gateway | Paginated past assessments (10/page). |
| POST /predict | ML service | Risk score + SHAP explanation for 8 vitals. |


### 3.5 UI/UX Design Principles

- Single-screen assessment form with sensible default vitals to ease trial.
- Immediate, colour-coded risk (green/amber/red) and a two-column factor breakdown.
- Tabbed navigation between Assess and History; loading and error states everywhere.
- 'Leave a field at 0 if not measured' guidance, matching the model's missing-value logic.


### 3.6 Security Design Considerations

- Strict request typing/validation at both the gateway (name) and ML service (Pydantic).
- The ML service is not publicly exposed; only the gateway can reach it.
- Minimal data collection; no passwords or sensitive identifiers stored.
- CORS controlled at the gateway.


### 3.7 Deployment Architecture

Local/development deployment runs four processes: MongoDB via Docker Compose, the FastAPI ML service via Uvicorn (:8000), the Node gateway (:5000), and the Vite dev server (:5173) which proxies /api to the gateway. Each tier can be containerised and moved to cloud hosts independently for production.

---


## Chapter 4 — Methodology / Model Development


### 4.1 Development Methodology

An experimental, iterative methodology was used. The ML core was developed as a controlled experiment (baseline first, then custom objectives compared under identical conditions), while the surrounding system was built iteratively, integrating one tier at a time.


### 4.2 Dataset Description

The Pima Indians Diabetes dataset (UCI) contains 768 patient records with 8 numeric features and a binary outcome; 268 patients (~34.9%) are diabetic, giving a moderate class imbalance. The eight features are Pregnancies, Glucose, BloodPressure, SkinThickness, Insulin, BMI, Diabetes Pedigree, and Age.


### 4.3 Data Preprocessing

In five columns (Glucose, BloodPressure, SkinThickness, Insulin, BMI) a recorded value of 0 is physiologically impossible and actually denotes a missing measurement. These zeros are converted to NaN. XGBoost handles missing values natively by learning a default branch direction, so no imputation is performed. Crucially, the identical transform is applied at serving time so inference sees data exactly as training did.


### 4.4 Proposed Algorithm / Model

XGBoost is gradient-agnostic: for each sample it needs only the first derivative (gradient) and second derivative (hessian) of the loss with respect to the raw margin z, where p = sigmoid(z) and y in {0,1}. We supply three custom objectives. All floor the hessian at 1e-6 for stability.

- Baseline — standard log-loss: grad = p - y, hess = p(1-p).
- (a) Weighted cross-entropy: weight = w if y=1 else 1; grad = weight*(p-y), hess = weight*p(1-p). We use w = 3.0.
- (b) Focal loss (gamma=2, alpha=0.75): FL = -alpha_t*(1-p_t)^gamma*log(p_t); the (1-p_t)^gamma factor focuses training on hard, misclassified positives.
- (c) Exponential false-negative penalty (gamma=2): for positives, L = exp(gamma*(1-p))*(-log p); the gradient tends to a bounded -exp(gamma) as p->0, with a Gauss-Newton hessian ~= exp(gamma*(1-p))*p(1-p).


### 4.5 Tools & Frameworks Used

- Python 3.14, XGBoost 3.2, scikit-learn 1.8, SHAP 0.51, NumPy 2.4, pandas 3.0, Matplotlib 3.10, FastAPI + Uvicorn, joblib.
- Node.js + Express, Mongoose, Axios; React 19 + Vite + TypeScript + Tailwind CSS; MongoDB + Docker Compose.


### 4.6 Training Procedure & Implementation Details

Every model shares one hyperparameter set so the loss function is the only variable; this makes any metric difference causally attributable to the loss.

*Table 6: Shared XGBoost hyperparameters*

| Parameter | Value |
|---|---|
| n_estimators | 200 |
| max_depth | 4 |
| learning_rate | 0.05 |
| subsample | 0.8 |
| colsample_bytree | 0.8 |
| reg_lambda | 1.0 |
| base_score | 0.5 |
| tree_method | hist |

Stability protocol: stratified 5-fold cross-validation repeated over 5 seeds {42,0,7,13,21} = 25 runs per model, reporting mean +/- std. Serving pitfall: with a custom objective XGBoost's predict_proba is invalid and predict returns the raw margin, so probability = sigmoid(predict(X, output_margin=True)) is computed manually everywhere — in the harness and in the live FastAPI service.

---


## Chapter 5 — Implementation & Testing


### 5.1 Module Implementation

- custom_objectives.py — picklable callable classes for the three losses plus a stable sigmoid; each carries its grad/hess derivation.
- compare_models.py — the experiment harness (CV x seeds, metrics, figures, results injection).
- train_cost_sensitive_model.py — trains the winning objective and saves the deployed model.
- main.py — FastAPI /predict: preprocessing, manual-sigmoid scoring, SHAP explanation.
- backend/server.js — Express gateway: /api/assess orchestration and /api/history.
- frontend/src/App.tsx — React UI: assess form, result panel, paginated history.


### 5.2 Integration

The tiers integrate over HTTP/JSON. The gateway separates the patient name from the eight vitals so the ML service receives exactly the fields its Pydantic model validates, calls the ML service via Axios, persists via Mongoose, and returns a single packaged response to the SPA, which uses a Vite dev-proxy so the browser uses a same-origin /api path.


### 5.3 Testing Strategy

- Functional: end-to-end assessment submitted through the API returns a valid score and is persisted; history pagination verified.
- Numerical: gradients/hessians asserted finite with a positive hessian floor; probabilities asserted within [0,1]; reloaded model re-checked.
- Statistical (the thesis test): the harness asserts at least one cost-sensitive model has higher recall AND fewer false negatives than the baseline, or the run fails.
- Performance & usability: sub-second predictions; UI loading/error states exercised.


### 5.4 Evaluation Metrics

- Recall / Sensitivity = TP/(TP+FN) — the primary safety metric (catching diabetics).
- F2-score — an F-measure weighting recall twice as heavily as precision.
- Precision, Specificity, Accuracy — context metrics.
- ROC-AUC and PR-AUC — threshold-independent ranking quality.
- False-negative count — the raw count of missed diabetics.
- Latency — per-prediction response time.


### 5.5 Error Handling & Edge Cases

- ML service unreachable -> gateway returns HTTP 503 with a clear message (ECONNREFUSED).
- Missing/blank patient name -> HTTP 400 before any ML call.
- A 0 in a zero-as-missing field is reported as '(not measured)' rather than a misleading literal value.
- NumPy types cast to native floats so JSON serialisation never fails.

---


## Chapter 6 — Results, Analysis & Discussion


### 6.1 Experimental Results

All numbers are mean +/- std across 25 runs (5-fold x 5-seed), at decision threshold 0.5.

*Table 7: Comparison of standard vs. cost-sensitive objectives*

| Model | Recall | F2 | Precision | Specificity | ROC-AUC | FN/fold |
|---|---|---|---|---|---|---|
| Standard | 0.610 | 0.620 | 0.671 | 0.838 | 0.826 | 20.9 |
| Weighted CE | 0.756 | 0.720 | 0.612 | 0.742 | 0.827 | 13.1 |
| Focal (deployed) | 0.770 | 0.728 | 0.602 | 0.725 | 0.825 | 12.3 |
| Exponential | 0.703 | 0.686 | 0.628 | 0.775 | 0.821 | 15.9 |


### 6.2 Comparison with Existing Methods

Against the standard-log-loss XGBoost baseline, the focal objective raises recall from 0.610 to 0.770 and cuts mean false negatives from 20.9 to 12.3 per fold — close to a halving of missed diabetics — while ROC-AUC is essentially unchanged (0.826 vs 0.825). The models are therefore not worse; they are re-tuned to a safer operating point on the same underlying ranking, trading some precision/specificity exactly as intended.


### 6.3 Performance Graphs & Figures

![Figure 1: ROC curves — all models overlap (AUC ~0.82): discrimination is preserved.](figures/roc.png)

*Figure 1: ROC curves — all models overlap (AUC ~0.82): discrimination is preserved.*

![Figure 2: Precision-Recall curves; average precision is within noise across models.](figures/pr.png)

*Figure 2: Precision-Recall curves; average precision is within noise across models.*

![Figure 3: Out-of-fold confusion matrices; the red false-negative cell drops from 102 (Standard) to 57 (Focal).](figures/confusion_grid.png)

*Figure 3: Out-of-fold confusion matrices; the red false-negative cell drops from 102 (Standard) to 57 (Focal).*

![Figure 4: Mean +/- std recall and false negatives over 25 runs; error bars do not overlap between Standard and Focal.](figures/recall_fn_bars.png)

*Figure 4: Mean +/- std recall and false negatives over 25 runs; error bars do not overlap between Standard and Focal.*

![Figure 5: Predicted-risk distributions; cost-sensitive losses push the diabetic mass to the right of the 0.5 line.](figures/prob_dist.png)

*Figure 5: Predicted-risk distributions; cost-sensitive losses push the diabetic mass to the right of the 0.5 line.*


### 6.4 Case Study / Real Usage Scenario

Through the live API, a borderline patient (Glucose 145, BMI 33.6, Age 50, Pedigree 0.55) returns a 70.04% risk with Glucose, Pedigree and Age cited as primary risk factors, whereas a low-risk patient (Glucose 85, BMI 26.6, Age 22) returns 12.34% with multiple protective factors. The deployed cost-sensitive model flags the borderline diabetic that the standard model was more likely to miss.


### 6.5 Discussion

The objectives behave exactly as their gradients predict. One caveat: cost-sensitive training deliberately inflates positive-class scores, so the served risk_percentage is a monotonic risk score, appropriate for triage and ranking, not a calibrated probability. Post-hoc isotonic/Platt calibration would recover calibrated values and is left as future work.

---


## Chapter 7 — Deployment


### 7.1 Deployment Process

Four processes are started in order: the database, the ML service, the gateway, then the frontend.

```
# 1. MongoDB
docker compose -f backend/docker-compose.yml up -d
# 2. ML engine (FastAPI)
./venv/bin/uvicorn main:app --port 8000
# 3. API gateway (Node)
cd backend && node server.js
# 4. Frontend (Vite)
cd frontend && npm run dev
```


### 7.2 Hardware Requirements

- Any modern multi-core CPU (no GPU required); ~2 GB RAM is sufficient.
- ~500 MB disk for dependencies, model, and MongoDB data volume.


### 7.3 API Endpoints / Usage

*Table 8: API usage*

| Endpoint | Body / Query | Returns |
|---|---|---|
| POST /api/assess | {patientName, 8 vitals} | {success, data:{risk_percentage, explanation}} |
| GET /api/history?page=n | page number | {data:[records], pagination} |
| POST /predict (internal) | {8 vitals} | {risk_percentage, explanation} |


### 7.4 Version Control (GitHub Workflow)

- Feature-branch workflow: develop on branches, open pull requests, review, then merge.
- Commits scoped per concern (ML core, gateway, frontend, report).


### 7.5 Reproducibility Instructions

```
# Reproduce the experiment, figures, and results table:
./venv/bin/python compare_models.py
# Train and deploy the winning cost-sensitive model:
./venv/bin/python train_cost_sensitive_model.py
# Seeds {42,0,7,13,21}; 5-fold stratified CV; results in results/ and figures/.
```

---


## Chapter 8 — Conclusion & Future Work


### 8.1 Conclusion

Rewriting XGBoost's objective so that false negatives are penalised — linearly (weighted CE), via hard-example focusing (focal), or exponentially (custom penalty) — yields a measurably safer diabetes screening model than standard XGBoost, with the safety gain isolated to the loss function under a controlled, repeated cross-validation protocol. The winning focal model is deployed inside a complete, explainable, distributed web application.


### 8.2 Limitations

- Trained and evaluated only on the public Pima cohort; external validity is unproven.
- The served score is an uncalibrated risk score, not a literal probability.
- Not a certified medical device; for educational/research use only.


### 8.3 Future Improvements

- Probability calibration (isotonic/Platt) on a holdout for clinically meaningful percentages.
- Validation on larger, more diverse, real-world clinical datasets.
- User authentication and per-clinician patient lists.
- Integration with electronic health records and containerised cloud deployment.

---


## References

1. T. Chen and C. Guestrin, "XGBoost: A Scalable Tree Boosting System," in Proc. KDD, 2016.
2. T.-Y. Lin, P. Goyal, R. Girshick, K. He, and P. Dollar, "Focal Loss for Dense Object Detection," in Proc. ICCV, 2017.
3. C. Elkan, "The Foundations of Cost-Sensitive Learning," in Proc. IJCAI, 2001.
4. S. M. Lundberg and S.-I. Lee, "A Unified Approach to Interpreting Model Predictions (SHAP)," in Proc. NeurIPS, 2017.
5. J. W. Smith et al., "Using the ADAP learning algorithm to forecast the onset of diabetes mellitus," Proc. SCAMC, 1988 (Pima Indians Diabetes dataset, UCI ML Repository).
6. FastAPI documentation, https://fastapi.tiangolo.com.
7. React documentation, https://react.dev. MongoDB documentation, https://www.mongodb.com/docs.

---


## Appendix A: Project Synopsis

A distributed, explainable diabetes-risk screening system whose XGBoost core uses a custom cost-sensitive loss to minimise false negatives. A 5-fold x 5-seed comparison shows recall rising from 0.61 to 0.77 and false negatives nearly halving versus standard XGBoost, with ROC-AUC preserved. The winning model is served in real time with SHAP explanations behind a React UI, Node gateway, and MongoDB store.


## Appendix B: Research Papers

Key papers underpinning this work: Chen & Guestrin (XGBoost, 2016); Lin et al. (Focal Loss, 2017); Elkan (Cost-Sensitive Learning, 2001); Lundberg & Lee (SHAP, 2017). Full citations appear in the References section.


## Appendix C: Guide Interaction Report (Mentor Log Book)

*Table 9: Guide interaction log*

| Date | Discussion Summary | Guide Signature |
|---|---|---|
| <<date>> | <<summary>> |  |
| <<date>> | <<summary>> |  |
| <<date>> | <<summary>> |  |


## Appendix D: User Manual & Installation Guide

Installation and run steps:

```
# Python ML environment
python -m venv venv && ./venv/bin/pip install fastapi uvicorn xgboost shap \
    scikit-learn pandas numpy matplotlib joblib
# Train/deploy the model
./venv/bin/python train_cost_sensitive_model.py
# Start the four services (see Chapter 7.1)
docker compose -f backend/docker-compose.yml up -d
./venv/bin/uvicorn main:app --port 8000
cd backend && npm install && node server.js
cd frontend && npm install && npm run dev
```

Usage: open the Vite URL, enter a patient name and the eight vitals (leave a field at 0 if not measured), and click Assess Risk. The History tab lists past assessments.


## Appendix E: Git / GitHub Commit History

The project is version-controlled with Git using a feature-branch + pull-request workflow. The full commit history (authors, dates, messages) is available in the repository hosting (<<repository URL>>).

